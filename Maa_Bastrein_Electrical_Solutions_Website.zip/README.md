# Maa Bastrein Electrical Solutions — Website

Files:
- index.html — complete website
- styles.css — responsive styling
- script.js — mobile menu + dynamic year
- logo.jpg — cropped logo from the supplied visiting card
- visiting-card.jpg — supplied visiting card used as a visual brand asset

Open `index.html` in a browser to preview.

Important:
- No phone number, email, opening hours, pricing, or other unverified business details were invented.
- Update the Google Maps search link if the exact shop pin/address becomes available.
- For production, replace the Google Fonts dependency with self-hosted fonts if desired.
